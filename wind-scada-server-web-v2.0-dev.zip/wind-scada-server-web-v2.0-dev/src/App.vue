<template>
  <a-config-provider :locale="locale">
    <div id="app">
      <router-view/>
    </div>
  </a-config-provider>
</template>

<script>
import { AppDeviceEnquire } from '@/utils/mixin'
import { mapGetters } from 'vuex'
import zhCN from 'ant-design-vue/lib/locale-provider/zh_CN' // 中文
import zhTW from 'ant-design-vue/lib/locale-provider/zh_TW' // 繁体
import enUS from 'ant-design-vue/lib/locale-provider/en_US' // 英语美式

export default {
  mixins: [AppDeviceEnquire],
  data() {
    return {
      locale: zhCN,
    }
  },
  computed: {
    ...mapGetters(['lang']),
  },
  watch: {
    lang(newVal, oldVal) {
      if (newVal === 'zh-CN') {
        this.locale = zhCN
      } else if (newVal === 'en-US') {
        this.locale = enUS
      } else if (newVal === 'zh-TW') {
        this.locale = zhTW
      }
    },
  },
}
</script>
<style>
#app {
  height: 100%;
  width: 100%;
}
</style>
