import { axios } from '@/utils/request'

const sys = '/sys/'

const api = {
  user: sys + 'user',
  company: sys + 'company',
  role: sys + 'role',
  module: sys + 'module',
  rolePermission: sys + 'roleMenu',
  dictType: sys + 'dictType',
  dictData: sys + 'dictData',
  operLog: sys + 'operLog/list'
}

/** menu
 * 获取后端路由信息的 axios API
 * @returns {Promise}
 */
export function getRouterByUser(parameter) {
  return axios({
    url: api.user + '/menu',
    method: 'get',
    params: parameter
  })
}

export function operLog(parameter) {//参数修改日志
  return axios({
    url: api.operLog,
    method: 'post',
    params: parameter
  })
}

export function getInfo(parameter) {
  return axios({
    url: api.user + '/info',
    method: 'get',
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// user
export function getUserList(parameter) {
  return axios({
    url: api.user + '/list',
    method: 'get',
    params: parameter
  })
}

export function saveUser(parameter) {
  return axios({
    // url: api.user + (parameter.userId > 0 ? '/update' : '/save'),
    url: api.user + '/saveUser',
    method: 'post',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// dictType
export function getDictTypeList(parameter) {
  return axios({
    url: api.dictType + '/list',
    method: 'get',
    params: parameter
  })
}

export function saveDictType(parameter) {
  return axios({
    url: api.dictType + '/save',
    method: 'post',
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function delDictType(parameter) {
  return axios({
    url: api.dictType + '/deleteBatchList',
    method: 'post',
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// dictData
export function getDictDataList(parameter) {
  return axios({
    url: api.dictData + '/list',
    method: 'get',
    params: parameter
  })
}

export function saveDictData(parameter) {
  return axios({
    url: api.dictData + '/save',
    method: 'post',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function delDictData(parameter) {
  return axios({
    url: api.dictData + '/deleteBatchList',
    method: 'post',
    params: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

//传入字典类型type 获取字典表选项，填充下拉框
export function queryListByType(parameter) {
  return axios({
    url: api.dictData + '/queryListByType',
    method: 'POST',
    params: parameter
  })
}
