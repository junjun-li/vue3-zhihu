import {
  axios,
  wfAxios,
  instanceAxios
} from '@/utils/request'

const ems = '/ems/'

// const wfCode = process.env.VUE_APP_wfCode

const api = {
  exportDict: ems + 'dictType',
  config: ems + 'dictPara',
  turbineManage: ems + 'emsTurbine',
  turbineSyn: ems + 'emsTurbine/synchroTurbineByMongo'  //风机管理页面 手动同步风机
}

export const turbineManage = api.turbineManage + '/export' //风机管理导出  接口不走代理请求
export const exportPara = api.config + '/export' //参数管理导出  接口不走代理请求
export const exportDict = api.exportDict + '/export' //字典管理导出  接口不走代理请求

export function dictListAll(parameter) {//字典管理
  return axios({
    url: api.exportDict + '/listAll',
    method: 'POST',
    params: parameter
  })
}
export function sendParaToController(parameter) {//参数管理 下发至控制器
  return axios({
    url: api.config + '/sendPara',
    method: 'POST',
    params: parameter
  })
}
export function sendFanToController(parameter) {//风机管理 下发至控制器
  return axios({
    url: api.turbineManage + '/sendPara',
    method: 'POST',
    params: parameter
  })
}
//turbine
export function getTurbineList(parameter) {
  return axios({
    url: api.turbineManage + '/list',
    method: 'POST',
    params: parameter
  })
}
export function queryTurbineNameAndCode(parameter) {
  return axios({
    url: api.turbineManage + '/queryTurbineNameAndCode',
    method: 'POST',
    params: parameter
  })
}
export function saveTurbineParam(parameter) {
  return axios({
    url: api.turbineManage + '/updateByCode',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function turbineSynAction(parameter) {
  return axios({
    url: api.turbineSyn,
    method: 'POST',
    params: parameter
  })
}

// config 参数配置
export function getConfigList(parameter) {
  return axios({
    url: api.config + '/list',
    method: 'get',
    params: parameter
  })
}
export function saveConfig(parameter) {
  return axios({
    url: api.config + '/save',
    method: 'post',
    params: parameter
  })
}
export function delConfig(parameter) {
  return axios({
    url: api.config + '/delete',
    method: 'post',
    params: parameter
  })
}
export function getGroupName(parameter) {
  return axios({
    url: api.config + '/getGroupName',
    method: 'get',
    params: parameter
  })
}

export function getMapJson(parameter) {
  return axios({
    url: '../../../node_modules/echarts/map/json/province/' + parameter + '.json',
    method: 'get'
  })
}

// 获取故障记录数据
export const getftpTxtStatusListData = (data) => instanceAxios({
  url: '/DCL/report/getftpTxtStatusListData',
  method: 'post',
  data
})

// 获取 故障记录信息统计数据
export const getStatusCountTableData = (data) => instanceAxios({
  url: '/DCL/report/getStatusCountTableData',
  method: 'post',
  data
})

/**
 * 获取所有风机, 风机组
 */
export const getTurbineData = () => instanceAxios({
  url: '/DCL/report/getTurbineData',
  method: 'post'
})

/**
 * 报表配置信息列表查询接口
 * reportID参数详见 '@/views/report/config'
 * @param reportId 报表类型ID
 */
export const getReportConfigs = (reportId) => instanceAxios({
  url: `/DCL/report/getReportConfigs?reportId=${reportId}`,
  method: 'post'
})

/**
 * 保存报表查询配置
 * @param reportID 报表id 参数详见 '@/views/report/config'
 * @param name 配置名
 * @param query_term 配置的报表查询条件
 * @param id 如果是修改的话, 要多带一个id
 */
export const saveReportConfig = ({ reportId, name, query_term, id }) => instanceAxios({
  url: `/DCL/report/saveReportConfig`,
  method: 'post',
  data: {
    reportId,
    name,
    query_term,
    id
  }
})

/**
 * @param turbineCodes 以逗号分隔的风机编号，如：F0400001012,F0400001013,F0400001014
 * @param type 类型，如：years，months
 * @param date 日期，如：2018，201809
 * @param wfCode 风场编号
 * @returns {AxiosPromise}
 */
export const getPowerCurveAutoPrecautionaryChartData = ({ turbineCodes, type, date }) => instanceAxios({
  url: `/DCL/report/getPowerCurveAutoPrecautionaryChartData`,
  method: 'post',
  params: {
    turbineCodes,
    type,
    date,
    // wfCode
  }
})

/**
 * 风玫瑰图图形模式数据查询接口
 * @param turbineCode 风机编号
 * @param type 类型 'total' | 'years' | 'months'
 * @param date 日期 '' | '2020' | '202009'
 * @returns {AxiosPromise}
 */
export const getWindRoseChartData = ({ turbineCode, type, date }) => instanceAxios({
  url: `/CL/report/getWindRoseChartData`,
  method: 'post',
  params: {
    turbineCode,
    type,
    date
  }
})
/**
 * 风玫瑰图表格查询接口
 * @param turbineCode 风机编号
 * @param type 类型 'total' | 'years' | 'months'
 * @param date 日期 '' | '2020' | '202009'
 * @param pageNum 1
 * @param pageSize 10
 * @returns {AxiosPromise}
 */
export const getWindRoseTableData = ({ turbineCode, type, date, pageNum, pageSize }) => instanceAxios({
  url: `/CL/report/getWindRoseTableData`,
  method: 'post',
  params: {
    turbineCode,
    type,
    date,
    pageNum,
    pageSize
  }
})

/**
 * 风玫瑰图导出表格数据接口
 * @param turbineCode 风机编号
 * @param type 类型 'total' | 'years' | 'months'
 * @param date 日期 '' | '2020' | '202009'
 * @returns {AxiosPromise}
 */
export const windRoseExportExcel = ({ turbineCode, type, date }) => instanceAxios({
  url: `/CL/windRose/exportExcel`,
  method: 'get',
  params: {
    turbineCode,
    type,
    date
  },
  responseType: 'blob'
})

/**
 * 获取所有风机
 */
export const turbineGetTurbineData = () => wfAxios({
  url: `/CL/turbine/getTurbineData`,
  method: 'post',
  // params: {
  //   wfCode
  // }
})

/**
 * 导出功率曲线各个风机符合度
 * @param type 类型，如：years，months
 * @param date 日期，如：2018，201809
 */
export const powerCurveComplianceExportExcel = ({ type, date }) => wfAxios({
  url: `/report/powerCurveCompliance/exportExcel`,
  method: 'get',
  params: {
    // wfCode,
    type,
    date
  },
  responseType: 'blob'
})

/**
 * 功率曲线对比 => 获取图表类型数据
 */
export const getReadFtpTagsInfoData = (turbineCode) => wfAxios({
  url: `/report/getReadFtpTagsInfoData`,  //?wfCode=${wfCode}
  method: 'post'
})

/**
 * 功率曲线对比 => 获取表格数据
 * @param turbineCodes
 * @param type
 * @param date
 * @param wfCode
 */
export const getPowerCurveTableData = ({ pageNum, pageSize, turbineCodes, type, date }) => wfAxios({
  url: `/report/getPowerCurveTableData`,
  method: 'post',
  params: {
    pageNum,
    pageSize,
    turbineCodes,
    type,
    date,
    // wfCode
  }
})

/**
 * 功率曲线对比 => 获取图表数据
 * @param turbineCodes
 * @param type
 * @param date
 * @param wfCode
 */
export const getMultiPowerCurveChartData = ({ turbineCodes, type, date }) => wfAxios({
  url: `/report/getMultiPowerCurveChartData`,
  method: 'post',
  params: {
    turbineCodes,
    type,
    date,
    // wfCode
  }
})

/**
 * 导出功率曲线对比表格数据
 * @param type 类型，如：years，months
 * @param date 日期，如：2018，201809
 */
export const powerCurveComparisonExportExcel = ({ type, date }) => wfAxios({
  url: `/report/powerCurveComparison/exportExcel`,
  method: 'get',
  params: {
    // wfCode,
    type,
    date
  },
  responseType: 'blob'
})

// 故障模块
export function getFaultList(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryFaultInfoBy',
    method: 'POST',
    params: parameter
  })
}

export function getUnhandledFaultCount(parameter) {
  return wfAxios({
    url: '/faultAlarm/getTotalCountOfUnSolved',
    params: parameter,
    method: 'POST'
  })
}
// 获取所有风机编号
export function getTurbineNumber(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAllTurbineCodeBy',
    method: 'POST',
    params: parameter
  })
}

export function getFaultCountTop5(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultCountOfTopFive',
    method: 'POST',
    params: parameter
  })
}

export function getFaultTypeAndCount(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultTypeAndCount',
    method: 'POST',
    params: parameter
  })
}

export function getFaultTimeTop5(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultTurbineCodeOfTopFive',
    method: 'POST',
    params: parameter
  })
}

/** 查询不同分类类型下拉列表信息
 * @param typeSysCode
 *"T10":故障分类类型表
 *"T20":状态分类表
 *"T30"":偏航分类
 *"T40"":采集故障源类型
 *"T50"":故障处理状态
 *"T60"":状态码体系
 *"T70"":故障发布体系
 */
export function getTypeOptionsByFlag(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAllDataMinResType',
    method: 'POST',
    params: parameter
  })
}

export function getWorkCode(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultLogBy',
    method: 'POST',
    params: parameter
  })
}

// 获取所有风场
export function getAllWindField() {
  // let param = { wfCode: 'F040' }
  return wfAxios({
    url: '/faultAlarm/queryAllWindField',
    method: 'POST',
    // params: param
  })
}

// 获取指定风场下的对应风机
export function getTurbineCodeByWfName(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAllTurbineCodeBy',
    method: 'POST',
    params: parameter
  })
}

// 模糊查询故障状态码
export function getFaultStatusCodeByVague(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultStatusCodeBy',
    method: 'POST',
    params: parameter
  })
}

// 新增一条故障信息
export function addNewFault(parameter, wfCode) {
  return wfAxios({
    url: '/faultAlarm/saveFaultInfo',
    method: 'POST',
    // params: wfCode,
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 根据批次号查故障详情
export function getFaultInfoByBatchNo(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultInfoByBatchNo',
    method: 'POST',
    params: parameter
  })
}

// 根据故障ID查故障明细
export function getFaultInfoById(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultInfoByFaultId',
    method: 'POST',
    params: parameter
  })
}

// 根据批次号查首发故障
export function getFirstFaultByBatchNo(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultOfMainInfoBy',
    method: 'POST',
    params: parameter
  })
}

// 根据故障码查解决方案
export function getFaultSolutionInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultSolutionInfoBy',
    method: 'POST',
    params: parameter
  })
}

// 新增工单
export function addWorkOrder(parameter, wfCode) {
  return wfAxios({
    url: '/faultAlarm/insertWorkOrder',
    method: 'POST',
    // params: wfCode,
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 新增自定义解决方案
export function submitFaultSolution(parameter, wfCode) {
  return wfAxios({
    url: '/faultAlarm/saveFaultSolution',
    method: 'POST',
    // params: wfCode,
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 故障图片文件上传
export function uploadFaultPicFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/uploadFaultPicFile',
    method: 'POST',
    data: parameter
  })
}

// 获取故障状态码列表
export function getFaultStatusCode(parameter, wfCode) {
  return wfAxios({
    url: '/faultAlarm/queryFaultStatusCodeInfoBy',
    method: 'POST',
    // params: wfCode,
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 获取故障码体系选项
export function getFaultCodeSystem() {
  // let param = { wfCode: 'F040' }
  return wfAxios({
    url: '/faultAlarm/queryFaultSystemCodes',
    // params: param,
    method: 'POST'
  })
}

// 获取故障组选项
export function getFaultGroups() {
  // let param = { wfCode: 'F040' }
  return wfAxios({
    url: '/faultAlarm/getFaultGroupCollection',
    // params: param,
    method: 'POST'
  })
}

//  根据故障状态码ID查询故障状态码详情
export function getFaultStatusCodeInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultStatusCodeInfo',
    method: 'POST',
    params: parameter
  })
}

// 故障录播接口
export function submitRecordCondition(parameter) {
  return wfAxios({
    url: '/faultAlarm/saveFaultRecordParam',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 获取风机选项
export function getAllTurbines(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryTurbines',
    method: 'POST',
    params: parameter
  })
}

// 获取部套选项
export function getAllSuitInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAllSuitInfo',
    method: 'POST',
    params: parameter
  })
}

// 获取websocket数据
export function startScadaRecordFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/startScadaRecordFile',
    method: 'POST',
    params: parameter
  })
}

// 结束录播
export function stopScadaRecordFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/stopScadaRecordFile',
    method: 'POST',
    params: parameter
  })
}

// 故障录播文件上传
export function uploadFaultFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/uploadFaultFile',
    method: 'POST',
    data: parameter
  })
}

// 故障录播文件获取
export function getFaultFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/getFaultFile',
    method: 'POST',
    params: parameter
  })
}

// 故障录播文件删除
export function deleteFaultFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/deleteFaultFile',
    method: 'POST',
    params: parameter
  })
}

// 获取 手动录播列表数据
export function getFaultRecordInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryFaultRecordInfo',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 手动录播列表 录播文件查看
export function viewFaultRecordFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/getRecordFileOfManual',
    method: 'POST',
    params: parameter
  })
}

// 手动录播列表 录播文件删除
export function deleteFaultRecordFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/deleteFaultRecordFile',
    method: 'POST',
    params: parameter
  })
}

// 手动录播列表 录播文件上传
export function uploadManualRecordFile(parameter) {
  return wfAxios({
    url: '/faultAlarm/uploadRecordFile',
    method: 'POST',
    data: parameter
  })
}

// 越限告警 初始化展示的报表配置信息
export function getInitConfigData(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAlarm',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 机型选择
export function getAlarmDevice(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAlarmDevice',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 风机选择
export function getAlarmTurbine(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryAlarmTurbine',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 变量选择
export function getAlarmVariable(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryParam',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 展示图表
export function showConfig(parameter) {
  return wfAxios({
    url: '/faultAlarm/showConfig',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 越限告警 保存配置模板并展示图表
export function saveAlarmConfig(parameter) {
  return wfAxios({
    url: '/faultAlarm/showAndSaveConfig',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 越限告警 修改配置
export function updateConfig(parameter) {
  return wfAxios({
    url: '/faultAlarm/updateConfig',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 越限告警 配置模板选项
export function getConfigDeviceOption(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryConfigDevice',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 选择配置获取实时数据
export function getSelectedConfigData(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryTempAlarm',
    method: 'POST',
    params: parameter
  })
}

// 越限告警 配置模板信息回显数据
export function getAlarmConfigInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryConfigInfo',
    method: 'POST',
    params: parameter
  })
}

// 越限告警参数说明表
export function getParamInfo(parameter) {
  return wfAxios({
    url: '/faultAlarm/queryParamInfo',
    method: 'POST',
    data: parameter,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

// 获取风机状况信息实时接口
export const getTurbineRunStatus = (parameter) => wfAxios({
  url: `/monitoring/turbinePageData_socket`,
  method: 'POST',
  params: parameter
})

/**
 * 全场监控页面 获取页面展示字段接口
 * @param type 类型，如：years，months
 * @param date 日期，如：2018，201809
 */
export const getPageConfig = () => wfAxios({
  url: `/monitoring/getPageConfig`,
  method: 'POST',
  params: {
    // wfCode,
    flag: 'wf'
  }
})

/**
 * 全场监控  获取近七天发电量
 * @returns {AxiosPromise}
 */
export const getWFSevenDaysElec = () => wfAxios({
  url: `/monitoring/getWFSevenDaysElec`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 全场监控 获取近七天可用率数据
 * @returns {AxiosPromise}
 */
export const getWFSevenDaysAvailability = () => wfAxios({
  url: `/monitoring/getWFSevenDaysAvailability`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 全场监控 连接socket之后, 使用此接口告诉后台
 * 获取页面展示字段实时数据接口
 * @param sid 一个随机的uuid, 关闭socket时使用该id
 * @returns {AxiosPromise}
 */
export const wfPageConfigData_socket = (sid) => wfAxios({
  url: `/monitoring/wfPageConfigData_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid
  }
})

/**
 * 全场监控 获取风机运行状态数据字典
 * @returns {AxiosPromise}
 */
export const getTurbineRunStateType = () => wfAxios({
  url: `/monitoring/getTurbineRunStateType`,
  // url: `/monitoring/testStatus`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 全场监控 风机运行状态实时数据接口
 * @param sid 一个随机的uuid, 关闭socket时使用该id
 * @returns {AxiosPromise}
 */
export const wfTurbineRunStatus_socket = (sid) => wfAxios({
  url: `/monitoring/wfTurbineRunStatus_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid
  }
})

/**
 * 全场监控 获取风机信息
 * @returns {AxiosPromise}
 */
export const getMonitoringTurbineList = () => wfAxios({
  url: `/monitoring/getTurbineList`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 全场监控 故障告警消息弹窗 是否显示故障table
 * "isDisplayErrorMessage": "Y", 故障信息列表显示
 * "isDisplayWarnMessage": "N", 告警信息不显示
 * "isDisplayExpectMessage": "Y" 预警列表显示
 * @returns {AxiosPromise}
 */
export const getWFInfo = () => wfAxios({
  url: `/monitoring/getWFInfo`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 全场监控 视图模式 风机启动, 停机, 复位
 * @param type 1-启机 2-停机 3-冬季停机 4-复位 5-限功率 6-柴发控制
 * @param wfCode
 * @param turbineCode 风机集合
 * @param menuId 按钮id
 * @param url 按钮路径
 * 以下是可选参数
 * @param oUserName 操作员用户名
 * @param oPassword 操作员密码
 *
 * @param gUserName 监护员用户名
 * @param gPassword 监护员密码
 *
 * @param 限功率 "limitingPower":{
 *  "powerType":1, // 限功率类型
 *  示例 1-有功功率 2-无功功率 3-功率因素
 *  取消的话不用传下列参数 4-取消有功功率，5-取消无功功率，6-取消功率因素
 *
 *  "activePower":1, // 有功功率
 *  "reactivePower":1, // 无功功率
 *  "factor":1 // 功率因素
 *
 * },
 */
export const turbineOperation = (
  {
    type,
    turbineCodes,
    menuId,
    url,
    oname,
    opd,
    gname,
    gpd,
    limitingPower
  }) => wfAxios({
    url: `/monitoring/turbineOperation`,
    method: 'POST',
    data: {
      type,
      // wfCode,
      turbineCodes,
      menuId,
      url,
      oname,
      opd,
      gname,
      gpd,
      limitingPower
    }
  })

/**
 * 全场监控 视图模式
 * 获取 风机信息卡片：风机状态（状态左侧竖线颜色与风机状态颜色对应）、
 * 风机名称、风机图标（与状态对应的图标）、风速信息（含图标）、转速信息（含图标）、有功功率（含图标）
 * @param sid 一个随机的uuid, 关闭socket时使用该id
 * @param turbineCode 风机号
 */
export const wfTurbineInfo_socket = (sid) => wfAxios({
  url: `/monitoring/wfTurbineInfo_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid
  }
})

/**
 * 故障实时消息 页面左侧弹框 消息弹窗数量实时数据接口
 * @param sid
 */
export const wfMessageNum_socket = (sid) => wfAxios({
  url: `/monitoring/wfMessageNum_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid
  }
})

/**
 * 故障实时消息 页面左侧弹框 列表 实时数据接口
 * @param sid
 */
export const wfMessageList_socket = (sid) => wfAxios({
  url: `/monitoring/wfMessageList_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid
  }
})

/**
 * 单机监控 获取单机页面展示字段实时数据接口
 * @param sid 一个随机的uuid, 关闭socket时使用该id
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const turbinePageData_socket = ({ sid, turbineCode }) => wfAxios({
  url: `/monitoring/turbinePageData_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid,
    turbineCode
  }
})

/**
 * 获取风机所有部件接口
 * @param turbineCode 风机号
 * @returns {AxiosPromise}
 */
export const getTurbineComponents = (turbineCode) => wfAxios({
  url: `/monitoring/getTurbineComponents`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode
  }
})

/**
 * 单机监控 获取风机详情接口
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const getTurbineInfo = (turbineCode) => wfAxios({
  url: `/monitoring/getTurbineInfo`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode
  }
})

/**
 * 单机监控 获取风机所有部件指标配置接口
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const getTurbineComponentIndexConfig = (turbineCode) => wfAxios({
  url: `/monitoring/getTurbineComponentIndexConfig`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode
  }
})

/**
 * 单机监控
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const getTurbineSevenDaysElec = (turbineCode) => wfAxios({
  url: `/monitoring/getTurbineSevenDaysElec`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode
  }
})

/**
 * 单机监控 单风机功率曲线接口
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const getTurbinePowerCurveData = (turbineCode) => wfAxios({
  url: `/monitoring/getTurbinePowerCurveData`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode
  }
})

/**
 * 单机监控 单风机历史趋势图接口
 * @param turbineCode 风机编号
 * @returns {AxiosPromise}
 */
export const getTurbineComponentIndexData = ({ turbineCode, indexName }) => wfAxios({
  url: `/monitoring/getTurbineComponentIndexData`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode,
    indexName
  }
})

/**
 * 单机监控 单风机故障记录接口
 * @param turbineCode 风机号
 * @param type 类型：1-故障 2-事件 3-包含服务模式下的故障（多选，默认是1）
 * @param pageIndex 页码
 * @param pageSize 当前页显示条数
 * @returns {AxiosPromise}
 */
export const getTurbineFaultData = ({ turbineCode, type, pageIndex, pageSize }) => wfAxios({
  url: `/monitoring/getTurbineFaultData`,
  method: 'POST',
  params: {
    // wfCode,
    turbineCode,
    type,
    pageIndex,
    pageSize,
  }
})

/**
 * 单机监控 单风机实时故障接口
 * @param sid
 */
export const turbineFaultInfo_socket = ({ sid, turbineCode }) => wfAxios({
  url: `/monitoring/turbineFaultInfo_socket`,
  method: 'POST',
  params: {
    // wfCode,
    sid,
    turbineCode
  }
})

// 配置页面接口
// 三方系统配置添加接口
export function addTripartite(parameter) {
  return wfAxios({
    url: '/systemConfiguration/add',
    method: 'POST',
    params: parameter
  })
}

// 故障组别名接口
export function getFaultGroupSysNames(parameter) {
  return wfAxios({
    url: '/systemConfiguration/getFaultGroupSysNames',
    method: 'POST',
    params: parameter
  })
}

// 配置列表查詢接口,搜索接口
export function systemConfiguration(parameter) {
  return wfAxios({
    url: '/systemConfiguration/list',
    method: 'POST',
    params: parameter
  })
}

// 实时报表风机查询接口
export function getTurbine(parameter) {
  return wfAxios({
    url: '/turbine/getTurbineData',
    method: 'POST',
    params: parameter
  })
}
// 实时报表变量选择接口
export function getInfos(parameter) {
  return wfAxios({
    url: '/dictionary/getInfos',
    method: 'POST',
    params: parameter
  })
}
// 报表配置信息列表查询接口
export function searchReportConfigs(parameter) {
  return wfAxios({
    url: '/reportConfig/searchReportConfigs',
    method: 'POST',
    params: parameter
  })
}
// 风机实时数据接口
export function getRealTimeReportData(parameter) {
  return wfAxios({
    url: '/report/getRealTimeReportData',
    method: 'POST',
    params: parameter
  })
}
// 报表查询配置信息保存
export function saveReport(parameter) {
  return wfAxios({
    url: '/reportConfig/saveReportConfig',
    method: 'POST',
    params: parameter
  })
}

// 报表查询配置信息保存
export function updateReportConfig(parameter) {
  return wfAxios({
    url: '/reportConfig/updateReportConfig',
    method: 'POST',
    params: parameter
  })
}

// 删除接口
export function systemConfigurationDelete(parameter) {
  return wfAxios({
    url: '/systemConfiguration/delete',
    method: 'POST',
    params: parameter
  })
}
/**
 * 获取操作按钮权限接口
 * @param sid
 */
export const getAllButtonPermissionsInfo = () => wfAxios({
  url: `/monitoring/getAllButtonPermissionsInfo`,
  method: 'POST',
  // params: {
  //   wfCode
  // }
})

/**
 * 操作员和监护员确认验证接口
 * @param type 1-操作员 2-监护员
 * @param userName 用户名
 * @param password 密码
 * @param wfCode
 * @returns {AxiosPromise}
 */
export const confirmUserLogin = ({ type, userName, password }) => wfAxios({
  url: `/monitoring/confirmUserLogin`,
  method: 'POST',
  data: {
    // wfCode,
    type,
    userName,
    password
  }
})
