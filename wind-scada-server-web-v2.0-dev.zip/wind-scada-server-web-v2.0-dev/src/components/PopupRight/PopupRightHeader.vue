<template>
  <div
    :class="`popup-right-header-${theme}`"
    class="popup-right-header">
    <div class="left-title">
      <!--      <div-->
      <!--        :style="{ borderColor: color }"-->
      <!--        class="text">{{ titleText }}信息-->
      <!--      </div>-->
      <div class="xian"></div>
      <div class="text">
        {{ titleText }}信息
      </div>
      <a-button
        style="margin-left: 10px;margin-right: 10px;"
        type="primary">
        查看所有{{ titleText }}
      </a-button>
      <a-dropdown overlayClassName="green">
        <a-menu
          slot="overlay"
          @click="handleMenuClick">
          <a-menu-item key="1">
            <a-icon
              :component="singleMonitorStart"
              style="color: #11D8D8" />
            <span>启动</span>
          </a-menu-item>
          <a-menu-item key="2">
            <a-icon
              :component="singleMonitorStop"
              style="color: #F14B13" />
            <span>停机</span>
          </a-menu-item>
          <a-menu-item key="3">
            <a-icon
              :component="singleMonitorReset"
              style="color: #16A3F2" />
            <span>复位</span>
          </a-menu-item>
        </a-menu>
        <a-button style="margin-left: 8px">
          批量操作
          <a-icon type="down" />
        </a-button>
      </a-dropdown>
      <!--      <a-popover placement="bottomRight">-->
      <!--        <template-->
      <!--          slot="content"-->
      <!--          style="background: #143845;">-->
      <!--          <div class="dropdown-menu">-->
      <!--            <div-->
      <!--              class="dropdown-menu-item">-->
      <!--              <a-icon-->
      <!--                :component="singleMonitorStart"-->
      <!--                style="color: #11D8D8" />-->
      <!--              <span>启动</span>-->
      <!--            </div>-->
      <!--            <div-->
      <!--              class="dropdown-menu-item">-->
      <!--              <a-icon-->
      <!--                :component="singleMonitorStop"-->
      <!--                style="color: #F14B13" />-->
      <!--              <span>停机</span>-->
      <!--            </div>-->
      <!--            <div-->
      <!--              class="dropdown-menu-item">-->
      <!--              <a-icon-->
      <!--                :component="singleMonitorReset"-->
      <!--                style="color: #16A3F2" />-->
      <!--              <span>复位</span>-->
      <!--            </div>-->
      <!--          </div>-->
      <!--        </template>-->
      <!--        <a-button>-->
      <!--          <span>批量操作</span>-->
      <!--          <a-icon type="down" />-->
      <!--        </a-button>-->
      <!--      </a-popover>-->
    </div>
    <div class="right-btn">
      <!--      <a-button :style="{ borderColor: color,color, marginRight: '10px' }">查看所有{{ titleText }}-->
      <!--      </a-button>-->
      <!--      <a-button :style="{ borderColor: color,color, marginRight: '10px' }">-->
      <!--        <a-icon type="sound" />-->
      <!--        音效开启-->
      <!--      </a-button>-->
      <!--      <a-button :style="{ borderColor: color, color, marginRight: '10px' }">-->
      <!--        <a-icon type="bell" />-->
      <!--        消息开启-->
      <!--      </a-button>-->
      <div class="msg-num">
        <a-icon :component="location" />
        当前{{ titleText }}
        <!--:style="{ color }"-->
        <span style="">{{ number }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import {
  location,
  singleMonitorStart,
  singleMonitorStop,
  singleMonitorReset
} from '@/core/icons'
import { mapGetters } from 'vuex'

export default {
  name: 'PopupRightHeader',
  // props: {
  //   titleText: {
  //     type: String
  //   },
  //   color: {
  //     type: String
  //   },
  //   number: {
  //
  //   }
  // },
  props: ['titleText', 'color', 'number'],
  components: {},
  data () {
    return {
      location,
      singleMonitorStart,
      singleMonitorStop,
      singleMonitorReset
    }
  },
  methods: {
    handleMenuClick({ key }) {
      this.$emit('handleTurbineOperation', key)
    }
  },
  computed: {
    ...mapGetters({
      theme: 'theme'
    })
  }
}
</script>

<style
  lang="less"
  scoped>
.popup-right-header {
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .left-title {
    display: flex;
    align-items: center;
    .xian {
      width: 6px;
      height: 20px;
      background: linear-gradient(360deg, #188EFC 0%, #11D8D8 100%);
      border-radius: 3px;
    }
    .text {
      //padding-left: 10px;
      //border-left: 3px solid #fa531c;
      line-height: 1;
      margin-left: 10px;
      //color: #FFFFFF;
    }
  }
  .right-btn {
    display: flex;
    .msg-num {
      color: rgba(255, 255, 255, 0.8);
      line-height: 32px;
      span {
        font-weight: 500;
        font-size: 24px;
      }
    }
  }
}

.popup-right-header-green {
  .left-title {
    .text {
      color: #fff;
    }
  }
}
</style>
