<template>
  <div
    :class="[`early-warning-msg-${theme}`, theme]"
    :style="{height: height + 'px'}"
    class="early-warning-msg">
    <PopupRightHeader
      :number="dataList.num"
      color="#b371f9"
      titleText="预警" />
    <div class="table-container">
      <a-table
        :columns="columns"
        :data-source="tableData"
        :pagination="false"
        :row-selection="{
          selectedRowKeys: selectedRowKeys,
          onChange: onSelectChange
        }"
        :rowKey="(record, index) => index"
        :scroll="{ y: height - 72 - 41 }">
        <span
          slot="icon"
          slot-scope="text, record, index">
          <a-icon
            v-if="record.showIcon"
            :component="alarm"
            style="font-size: 20px" />
        </span>
      </a-table>
    </div>
  </div>
</template>

<script>
import PopupRightHeader from '@/components/PopupRight/PopupRightHeader'
import { mapGetters } from 'vuex'
import { alarm } from '@/core/icons'

export default {
  name: 'EarlyWarningMsg',
  props: {
    height: Number,
    dataList: Object
  },
  components: { PopupRightHeader },
  data () {
    return {
      alarm,
      columns: [
        {
          dataIndex: 'icon',
          title: '',
          scopedSlots: { customRender: 'icon' },
          width: 50
        },
        {
          dataIndex: 'turbineName',
          title: '风机名称'
        },
        {
          dataIndex: 'faultDesc',
          title: '预警描述'
        },
        {
          dataIndex: 'faultSource',
          title: '预警源'
        },
        {
          dataIndex: 'time',
          title: '激活时间',
          customRender: (text, row, index) => {
            return this.parseTime(text)
          }
        }
      ],
      tableData: [],
      selectedRowKeys: [],
      totalText: ''
    }
  },
  methods: {
    onSelectChange (selectedRowKeys) {
      console.log('selectedRowKeys changed: ', selectedRowKeys)
      this.selectedRowKeys = selectedRowKeys
    },
    parseTime (time) {
      return `${time.substr(0, 4)}-${time.substr(4, 2)}-${time.substr(6, 2)} ${time.substr(8, 2)}:${time.substr(10, 2)}:${time.substr(12, 2)}:${time.substr(14)}`
    }
  },
  computed: {
    ...mapGetters({
      theme: 'theme'
    })
  },
  watch: {
    dataList: function(newVal, oldVal) {
      if (newVal && newVal.list && Array.isArray(newVal.list)) {
        let data = newVal.list.map(item => {
          let timestamp = new Date(this.parseTime(item.time)).getTime()
          return {
            ...item,
            timestamp
          }
        })
        this.tableData = data.sort((a, b) => b.timestamp - a.timestamp)
        let onData = this.tableData[0]
        if (onData) {
          this.tableData = this.tableData.map(item => {
            if (item.time === onData.time) {
              return {
                ...item,
                showIcon: true
              }
            } else {
              return {
                ...item,
                showIcon: false
              }
            }
          })
        }
      }
    }
  }
}
</script>

<style
  lang="less"
  scoped>
.early-warning-msg {
  background: #fff;
  overflow: hidden;
  .pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 20px;
  }
  ///deep/ .ant-table-thead > tr >th{
  //  background: #fff1f1 !important;
  //}
}

.early-warning-msg-blue {
  background: #fff;
}

.early-warning-msg-green {
  background: rgba(0, 0, 0, 0.15);
}
</style>
