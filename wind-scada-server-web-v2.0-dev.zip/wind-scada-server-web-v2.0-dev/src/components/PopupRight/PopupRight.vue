<template>
  <div
    ref="PopupRight"
    class="popup-right">
    <a-drawer
      :bodyStyle="bodyStyle"
      :closable="false"
      :drawerStyle="drawerStyle"
      :visible="visible"
      placement="right"
      style="height: 100%;top: 0;bottom: 0"
      width="1300"
      zIndex="1100"
      @close="onClose">
      <div class="popup-right-content">
        <!--故障信息列表显示-->
        <FaultMsg
          v-if="isShow.isDisplayErrorMessage === 'Y'"
          :dataList="errorData"
          :height="itemHeight" />
        <!--告警信息-->
        <WarningMsg
          v-if="isShow.isDisplayWarnMessage === 'Y'"
          :dataList="warnData"
          :height="itemHeight"
          style="margin-top: 20px;" />
        <!--预警列表-->
        <EarlyWarningMsg
          v-if="isShow.isDisplayExpectMessage === 'Y'"
          :dataList="expectData"
          :height="itemHeight"
          style="margin-top: 20px;" />
      </div>
      <!-- slot="handle" 设置后抽屉直接挂载到 DOM 上，你可以通过该 handle 控制抽屉打开关闭-->
      <div
        slot="handle"
        class="setting-drawer-index-handle"
        @click="toggle">
        <a-badge
          :count="totalNum"
          :number-ant-drawer-bodytyle="{
            backgroundColor: '#fff',
            color: '#fa531c',
            padding:'0 2px',
            top:'2px',
            right:'-13px',
            height:'16px',
            lineHeight:'16px'
          }">
          <!--<a-icon-->
          <!--  v-if="!visible"-->
          <!--  type="alert" />-->
          <!--<a-icon-->
          <!--  v-else-->
          <!--  type="alert" />-->
          <a-icon type="alert" />
        </a-badge>
      </div>
    </a-drawer>
  </div>
</template>

<script>
import bg from '@/assets/bg.png'
import FaultMsg from '@/components/PopupRight/FaultMsg'
import WarningMsg from '@/components/PopupRight/WarningMsg'
import EarlyWarningMsg from '@/components/PopupRight/EarlyWarningMsg'
import { WebSocketRequest } from '@/utils/socket'
import {
  getWFInfo,
  wfMessageList_socket,
  wfMessageNum_socket
} from '@/api'
import { mapGetters } from 'vuex'
import { v4 as uuid } from 'uuid'
import { debounce } from '@/utils/util'

const WBSOCKET1ID = uuid()
const WBSOCKET2ID = uuid()

export default {
  components: {
    EarlyWarningMsg,
    WarningMsg,
    FaultMsg
  },
  data () {
    return {
      isShow: {},
      bg,
      visible: false,
      totalNum: 0,
      wbSocket1: undefined,
      wbSocket2: undefined,
      bodyStyle: {
        height: '200px',
        overflow: 'auto'
      },
      itemHeight: 0,
      // 故障数据
      errorData: {},
      // 告警数据
      warnData: {},
      // 预警数据
      expectData: {}
    }
  },
  watch: {},
  mounted () {
    this.initWbSocket1()
    this.initWbSocket2()
  },
  created () {
    this._getWFInfo()
    this.initPage()
    this.$_initResizeEvent()
  },
  methods: {
    $_initResizeEvent() {
      window.addEventListener('resize', debounce(() => {
        this._getWFInfo()
      }, 500))
    },
    $_destroyResizeEvent() {
      window.removeEventListener('resize', debounce(() => {
        this._getWFInfo()
      }, 500))
    },
    async _getWFInfo () {
      let res = await getWFInfo()
      this.isShow = res.data
      let num = 0
      if (res.data) {
        if (res.data.isDisplayErrorMessage === 'Y') {
          num += 1
        }
        if (res.data.isDisplayWarnMessage === 'Y') {
          num += 1
        }
        if (res.data.isDisplayExpectMessage === 'Y') {
          num += 1
        }
        // console.log(num)
        this.initPage(num)
      }
    },
    initPage (num = 3) {
      this.$nextTick(() => {
        let documentHeight = document.documentElement.clientHeight
        let height = documentHeight + 'px'
        this.bodyStyle = {
          height,
          overflow: 'hidden',
          background: 'rgba(0, 0, 0, 0.4)'
        }
        this.itemHeight = ((documentHeight - (20 * (num - 1))) / num)
      })
    },
    onClose () {
      this.visible = false
    },
    toggle () {
      this.visible = !this.visible
    },
    initWbSocket1 () {
      let url = `ws://${process.env.VUE_APP_wfScada_GATEWAY}/monitoring/websocket/${WBSOCKET1ID}`
      this.wbSocket1 = new WebSocketRequest(url, WBSOCKET1ID)
      this.wbSocket1.onopen(async () => {
        await wfMessageNum_socket(WBSOCKET1ID)
      })
      this.wbSocket1.onmessage(res => {
        try {
          // console.log(`%c ${res}`, 'color:green;')
          this.totalNum = JSON.parse(res).totalNum
        } catch (e) {
          //console.log('WebSocket error observed:' + e)
        }
      })
    },
    initWbSocket2 () {
      let url = `ws://${process.env.VUE_APP_wfScada_GATEWAY}/monitoring/websocket/${WBSOCKET2ID}`
      this.wbSocket2 = new WebSocketRequest(url, WBSOCKET2ID)
      this.wbSocket2.onopen(async () => {
        await wfMessageList_socket(WBSOCKET2ID)
      })
      this.wbSocket2.onmessage(res => {
        try {
          let response = JSON.parse(res)
          this.errorData = response.errorData
          this.expectData = response.expectData
          this.warnData = response.warnData
          // 计算高度
          // let num = 0
          // for (let responseKey in response) {
          //   if (response[responseKey] && response[responseKey].num) {
          //     num += response[responseKey].num
          //   }
          // }
          // console.log(num)
          // this.initPage(num)
        } catch (e) {
          //console.log('WebSocket error observed:' + e)
        }
      })
    }
  },
  computed: {
    ...mapGetters({
      theme: 'theme'
    }),
    drawerStyle: function() {
      if (this.theme === 'green') {
        return {
          background: `url(${bg}) no-repeat center top`
        }
      } else {
        return {
          background: '#F0F2F5'
        }
      }
    }
  },
  destroyed () {
    this.wbSocket1.destroy()
    this.wbSocket2.destroy()
    this.$_destroyResizeEvent()
  }
}
</script>

<style
  lang="less"
  scoped>
.setting-drawer-index-handle {
  //position: absolute;
  //bottom: 5px;
  width: 44px;
  height: 32px;
  background: linear-gradient(90deg, #188EFC 0%, #11D8D8 100%);
  padding-left: 12px;
  right: 1300px;
  display: flex;
  /*justify-content: center;*/
  align-items: center;
  cursor: pointer;
  pointer-events: auto;
  z-index: 1001;
  text-align: center;
  font-size: 22px;
  border-radius: 30px 0 0 30px;
  position: fixed;
  //top: 800px;
  top: 50%;
  transform: translateY(-50%);
  i {
    color: rgb(255, 255, 255);
    font-size: 25px;
  }
  /deep/ .ant-badge-multiple-words{
    width: 20px;
    height: 20px;
    background: #fff;
    box-shadow: 0px 0px 4px 0px rgba(209, 209, 209, 0.5);
    border-radius: 10px;
    top: 1px;
    right: 5px;
    padding: 0 3px;
    color: #FA541C;
    font-weight: 600;
  }
}

/deep/ .ant-table-thead > tr > th,
/deep/ .ant-table-tbody > tr > td {
  padding: 10px;
}

.popup-right-content {
  //background: rgba(0, 0, 0, 0.4);
}

/deep/ .ant-drawer-body {
  padding: 0;
}

/deep/ .ant-drawer-content-wrapper {
  height: 100%;
}


</style>
