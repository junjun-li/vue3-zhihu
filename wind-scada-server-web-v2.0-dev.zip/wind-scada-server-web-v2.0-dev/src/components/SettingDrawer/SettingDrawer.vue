<template>
  <a-popover
    v-model="visible"
    trigger="click"
    placement="bottomRight"
    overlayClassName="header-notice-wrapper"
    :getPopupContainer="() => $refs.noticeRef.parentElement"
    :autoAdjustOverflow="true"
    :arrowPointAtCenter="true"
    :overlayStyle="{ width: '300px' }"
  >

    <template slot="content">

      <div :class="['setting-drawer-index-content', theme]">

        <div :style="{ marginBottom: '24px' }">
          <h3 class="setting-drawer-index-title">一键换肤</h3>

          <div class="setting-drawer-index-blockChecbox">

            <a-tooltip>
              <template slot="title">
                绿色整体风格
              </template>
              <div class="setting-drawer-index-item" @click="handleMenuTheme('green')">
                <img src="@/assets/bg.png" alt="green">
                <div class="setting-drawer-index-selectIcon green" v-if="navTheme === 'green'">
                  <a-icon type="check"/>
                </div>
              </div>
            </a-tooltip>

            <a-tooltip>
              <template slot="title">
                蓝色菜单风格
              </template>
              <div class="setting-drawer-index-item" @click="handleMenuTheme('blue')">
                <img src="@/assets/blue.svg" alt="blue">
                <div class="setting-drawer-index-selectIcon" v-if="navTheme === 'blue'">
                  <a-icon type="check"/>
                </div>
              </div>
            </a-tooltip>

            <a-tooltip>
              <template slot="title">
                暗色菜单风格
              </template>
              <div class="setting-drawer-index-item" @click="handleMenuTheme('dark')">
                <img src="https://gw.alipayobjects.com/zos/rmsportal/LCkqqYNmvBEbokSDscrm.svg" alt="dark">
                <div class="setting-drawer-index-selectIcon" v-if="navTheme === 'dark'">
                  <a-icon type="check"/>
                </div>
              </div>
            </a-tooltip>

            <a-tooltip>
              <template slot="title">
                亮色菜单风格
              </template>
              <div class="setting-drawer-index-item" @click="handleMenuTheme('light')">
                <img src="https://gw.alipayobjects.com/zos/rmsportal/jpRkZQMyYRryryPNtyIC.svg" alt="light">
                <div class="setting-drawer-index-selectIcon" v-if="navTheme == 'light'">
                  <a-icon type="check"/>
                </div>
              </div>
            </a-tooltip>
          </div>
        </div>

        <a-divider />

        <div :style="{ marginBottom: '24px' }">
          <h3 class="setting-drawer-index-title">主题色</h3>

          <div style="height: 20px">
            <a-tooltip class="setting-drawer-theme-color-colorBlock" v-for="(item, index) in colorList" :key="index">
              <template slot="title">
                {{ item.key }}
              </template>
              <a-tag :color="item.color" @click="changeColor(item.color)">
                <a-icon type="check" v-if="item.color === primaryColor"></a-icon>
              </a-tag>
            </a-tooltip>

          </div>
        </div>

        <a-divider />

        <div :style="{ marginBottom: '24px' }">
          <voice-message />
        </div>

        <a-divider />

        <div :style="{ marginBottom: '24px' }">
          <lang-select />
        </div>

        <a-divider />

        <div :style="{ marginBottom: '24px' }">
          <monitor-select />
        </div>

      </div>

    </template>
    <span @click="fetchSeeting" class="header-notice" ref="noticeRef" style="padding: 0 18px">
      <a-icon type="setting"/>
    </span>
  </a-popover>
</template>

<script>
import { mapGetters } from 'vuex'
import LangSelect from '@/components/tools/LangSelect'
import MonitorSelect from '@/components/tools/MonitorSelect'
import VoiceMessage from '@/components/tools/VoiceMessage'
import SettingItem from './SettingItem'
import { updateTheme, updateColorWeak, colorList } from './settingConfig'
import { mixin, mixinDevice } from '@/utils/mixin'

export default {
  components: {
    LangSelect,
    SettingItem,
    MonitorSelect,
    VoiceMessage
  },
  mixins: [mixin, mixinDevice],
  data () {
    return {
      loading: false,
      visible: false,
      colorList
    }
  },
  computed: {
    ...mapGetters(['theme']),
  },
  methods: {
    fetchSeeting () {
      this.visible = !this.visible
    },
    onColorWeak (checked) {
      this.$store.dispatch('ToggleWeak', checked)
      updateColorWeak(checked)
    },
    onMultiTab (checked) {
      this.$store.dispatch('ToggleMultiTab', checked)
    },
    handleMenuTheme (theme) {
      this.$store.dispatch('ToggleTheme', theme)
    },
    handleLayout (mode) {
      this.$store.dispatch('ToggleLayoutMode', mode)
      // 因为顶部菜单不能固定左侧菜单栏，所以强制关闭
      this.handleFixSiderbar(false)
    },
    handleContentWidthChange (type) {
      this.$store.dispatch('ToggleContentWidth', type)
    },
    changeColor (color) {
      if (this.primaryColor !== color) {
        this.$store.dispatch('ToggleColor', color)
        updateTheme(color)
      }
    },
    handleFixedHeader (fixed) {
      this.$store.dispatch('ToggleFixedHeader', fixed)
    },
    handleFixedHeaderHidden (autoHidden) {
      this.$store.dispatch('ToggleFixedHeaderHidden', autoHidden)
    },
    handleFixSiderbar (fixed) {
      if (this.layoutMode === 'topmenu') {
        this.$store.dispatch('ToggleFixSiderbar', false)
        return
      }
      this.$store.dispatch('ToggleFixSiderbar', fixed)
    }
  }
}
</script>

<style lang="less" scoped>
  .setting-drawer{float:left;position:relative}

  .setting-drawer-index-content {
  .setting-drawer-index-blockChecbox {
      display: flex;

    .setting-drawer-index-item {
        margin-right: 16px;
        position: relative;
        border-radius: 4px;
        cursor: pointer;

        img {
          width: 25px;
          height: 25px;
          border-radius:2px
        }

      .setting-drawer-index-selectIcon {
          position: absolute;
          top: 0;
          right: 0;
          width: 100%;
          padding-top: 7px;
          padding-left: 11px;
          height: 100%;
          color: #1890ff;
          font-size: 12px;
          font-weight: 700;
        &.green{
            color:#fff;
          }
        }
      }
    }
  .setting-drawer-theme-color-colorBlock {
      width: 20px;
      height: 20px;
      border-radius: 2px;
      float: left;
      cursor: pointer;
      margin-right: 8px;
      padding-left: 0px;
      padding-right: 0px;
      text-align: center;
      color: #fff;
      font-weight: 700;

      i {
        font-size: 14px;
      }
    }
  }

  .setting-drawer-index-handle {
    position: absolute;
    top: 0;
    width: 48px;
    height: 56px;
    right: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    pointer-events: auto;
    z-index: 1001;
    text-align: center;
    font-size: 16px;
    border-radius: 4px 0 0 4px;
    i {
      color: rgba(0, 0, 0, 0.5);
      font-size: 20px;
    }
  }

  .green .setting-drawer-index-handle {
    i {
      color: #11D8D8
    }
  }

  .header-notice{
    display: inline-block;
    transition: all 0.3s;

    span {
      vertical-align: initial;
    }

    .anticon-setting{font-size: 18px; cursor: pointer}
  }

  .ant-list-item{padding:10px 0 0}
</style>

