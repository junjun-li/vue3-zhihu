<template>
  <a-icon class="icon" :type="isFullscreen ? 'fullscreen' : 'fullscreen-exit'" @click="click" />

</template>

<script>
  import screenfull from 'screenfull'

  //    全屏功能使用:1.安装,npm install --save ScreenFull
  //             2.引入
  //             3.点击时判断浏览器是否可全屏,不可全屏给提示,可全屏执行screenfull.toggle()

  export default {
    name: 'ScreenFull',
    data() {
      return {
        isFullscreen: true,
        flag: false //点击全屏标识
      }
    },
    mounted() {
      this.init()

      // //监听键盘按键事件
      // var self = this
      // document.addEventListener('keyup', function (e) {
      //   //此处填写你的业务逻辑即可
      //   if (e.keyCode == 27) {
      //     self.closeScreenFull()
      //   }
      // })

      var self = this
      window.onresize = () => {
        if (self.isFullscreen && self.flag) {
          self.openScreenFull()
        } else{
          self.closeScreenFull()
        }
      }

    },
    beforeDestroy() {
      this.destroy()
    },
    methods: {
      click() {
        if (!screenfull.isEnabled) {
          this.$message({
            message: 'you browser can not work',
            type: 'warning'
          })
          return false
        }
        this.flag = true
        screenfull.toggle()
      },
      openScreenFull() {  //打开大屏模式
        if(document.getElementsByClassName('header-animat')[0]){
          document.getElementsByClassName('header-animat')[0].style.display = 'none'
        }
        if(document.getElementsByClassName('ant-layout-sider')[0]){
          document.getElementsByClassName('ant-layout-sider')[0].style.display = 'none'
        }
        if(document.getElementsByClassName('page-header')[0]){
          document.getElementsByClassName('page-header')[0].style.display = 'none'
        }

        this.isFullscreen = false
      },
      closeScreenFull() { //关闭大屏模式
        if(document.getElementsByClassName('header-animat')[0]){
          document.getElementsByClassName('header-animat')[0].style.display = 'block'
        }
        if(document.getElementsByClassName('ant-layout-sider')[0]){
          document.getElementsByClassName('ant-layout-sider')[0].style.display = 'block'
        }
        if(document.getElementsByClassName('page-header')[0]){
          document.getElementsByClassName('page-header')[0].style.display = 'block'
        }
        this.isFullscreen = true
        this.flag = false
      },
      change() {
        this.isFullscreen = screenfull.isFullscreen
      },
      init() {
        if (screenfull.enabled) {
          screenfull.on('change', this.change)
        }
      },
      destroy() {
        if (screenfull.enabled) {
          screenfull.off('change', this.change)
        }
      }
    }
  }
</script>
<style scoped>
  .icon {
    font-size: 18px;
    margin: 0 20px;
  }
</style>