<template>
  <a-popover
    v-model="visible"
    trigger="click"
    placement="bottomRight"
    overlayClassName="header-notice-wrapper"
    :getPopupContainer="() => $refs.noticeRef.parentElement"
    :autoAdjustOverflow="true"
    :arrowPointAtCenter="true"
    :overlayStyle="{ width: '300px' }"
  >
    <template slot="content">
      <div :class="['setting-drawer-index-content', theme]">
        <a-spin :spinning="loading">
          <a-tabs>
            <a-tab-pane tab="系统消息" key="1">
              <a-list size="small" :data-source="data">
                <a-list-item slot="renderItem" slot-scope="item">
                  <a-list-item-meta>
                    <a slot="title" href="javascript:;">{{ item }}</a>
                    <a-avatar slot="avatar"/>
                  </a-list-item-meta>
                </a-list-item>
              </a-list>
            </a-tab-pane>
            <a-tab-pane tab="消息" key="2">
              <a-list size="small" :data-source="data2">
                <a-list-item slot="renderItem" slot-scope="item">
                  <a-list-item-meta>
                    <a slot="title" href="javascript:;">{{ item }}</a>
                    <a-avatar slot="avatar"/>
                  </a-list-item-meta>
                </a-list-item>
              </a-list>
            </a-tab-pane>
          </a-tabs>
          <a-icon style="position:absolute;right:-15px;top:14px;font-size: 16px; color: #11d8d8;cursor:pointer" type="bell"/>
        </a-spin>
      </div>
    </template>
    <span @click="fetchNotice" class="header-notice" ref="noticeRef" style="padding: 0 18px">
      <a-badge count="12">
        <a-icon style="font-size: 16px; padding: 4px" type="bell" />
      </a-badge>
    </span>
  </a-popover>
</template>

<script>
export default {
  name: 'HeaderNotice',
  data () {
    return {
      loading: false,
      visible: false,
      data: [
        '房东房客三方接口是否记得看过简单快速的。',
        'i已经看过和美国空军反馈给。',
        '二v从v从v',
        '报告和皇家游艇会刚刚回归12345667！',
        '合同合同有部。',
        'i已经看过和。',
        '二v从v从v',
        '报告和皇家游！',
        '合同合同。',
        'i已经看过和美。'
      ],
      data2: [
        'Racing car sprays burning fuel into crowd.',
        'Japanese princess.',
        'Australian walks 100km after outback crash.',
        'Man charged over missing wedding girl.',
        'Los Angeles battles huge wildfires.'
      ],
    }
  },
  methods: {
    fetchNotice () {
      if (!this.visible) {
        this.loading = true
        setTimeout(() => {
          this.loading = false
        }, 1000)
      } else {
        this.loading = false
      }
      this.visible = !this.visible
    }
  }
}
</script>

<style lang="less" scoped>
  /*.header-notice-wrapper {*/
    /*top: 50px !important;*/
  /*}*/
  .header-notice{
    display: inline-block;
    transition: all 0.3s;

    span {
      vertical-align: initial;
    }
  }
  .ant-list-split .ant-list-item{
    border-bottom: none;
    padding: 1px 0;
    a{
      font-weight: normal;
    }
    .ant-list-item-meta-avatar {
      margin: 9px 10px 9px 0;
      .ant-avatar {
        background: rgba(17, 216, 216, 0.6);
        width: 6px;
        height: 6px;
      }
    }
  }

  /*蓝绿版字体色*/
  .green{
    .ant-tabs {
      color: rgba(255, 255, 255, .8)
    }
    .ant-list-split .ant-list-item{
      a{
        color: rgba(255,255,255, .8);
        &:hover{
          color: rgba(255,255,255, 1);
        }
      }
      &:hover{
        background: rgba(24, 142, 252, 0.3);
      }
    }
  }
</style>
