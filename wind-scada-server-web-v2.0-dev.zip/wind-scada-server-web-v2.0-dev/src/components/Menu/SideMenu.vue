<template>
  <a-layout-sider
    :class="['sider', isDesktop() ? null : 'shadow', theme, fixSiderbar ? 'ant-fixed-sidemenu' : null ]"
    width="210px"
    :collapsible="collapsible"
    v-model="collapsed"
    :trigger="null">
    <logo :theme="theme" :collapsed="collapsed"/>
    <div :class="`${CLASS} overflowSide`">
      <s-menu
        :collapsed="collapsed"
        :menu="menus"
        :theme="theme"
        :mode="mode"
        @select="onSelect"
        style="padding: 16px 0px;"></s-menu>
    </div>
  </a-layout-sider>

</template>

<script>
import { mapGetters } from 'vuex'
import Logo from '@/components/tools/Logo'
import SMenu from './index'
import { mixin, mixinDevice } from '@/utils/mixin'

export default {
  name: 'SideMenu',
  components: { Logo, SMenu },
  mixins: [mixin, mixinDevice],
  props: {
    mode: {
      type: String,
      required: false,
      default: 'inline'
    },
    theme: {
      type: String,
      required: false,
      default: 'green'
    },
    collapsible: {
      type: Boolean,
      required: false,
      default: false
    },
    collapsed: {
      type: Boolean,
      required: false,
      default: false
    },
    menus: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      CLASS: ''
    }
  },
  computed: {
    ...mapGetters(['height']),
  },
  created() {
    this.getHeightResize(this.height)
  },
  methods: {
    getHeightResize(height) {
      if(height >= '1080'){
        this.CLASS = 'height1080'
      } else{
        this.CLASS = ''
      }
    }
  },
  watch: {
    height (val) {
      this.getHeightResize(val)
    }
  }
}
</script>

<style lang="less" scoped>
  .overflowSide{
    height: 874px;
    overflow-y: auto;
    overflow-x: hidden;
    &.height1080{
      height: 987px;
    }
  }
</style>
