<template>
  <div :id="id" :data="data"></div>
</template>

<script>
import { mapGetters, mapState } from 'vuex'
  // require('echarts/theme/macarons') // echarts theme
  export default {
        name: 'BaseEchartsAllComponent',
        data(){
          return{
            ChartLineGraph:null,
            arr:[],
            start: 0,
            end: 100
          }
        },
        watch:{
          data:{
            handler(newvalue,oldvalue) {
              this.drawLineGraph(this.id,newvalue)
            },
            deep:true
            },
          navTheme:{
            handler(newvalue,oldvalue) {
              this.drawLineGraph(this.id,this.data)
            },
            deep:true
          }
        },
        props:{
            id: {
            type: String,
            default: ''
            },
            data: {
            type: Object,
            required: true
            }
        },
        mounted() {
          this.$nextTick(function(){
            setTimeout(() => {
              this.drawLineGraph(this.id,this.data)
            })
          })
        },
        computed: {
          ...mapState({
            navTheme: state => state.app.theme
          }),
          axisColor() {
            if(this.navTheme === 'green') {
              return 'rgba(255, 255, 255, 0.3)'
            }
            return '#000000'
          }
        },
        methods:{
         drawLineGraph(id,data){
            this.arr = []
              for(var k in data){
                this.arr.push(data[k])
            }
            const len = this.arr.length -1
            const length = this.arr.length-2
            const leng= this.arr.length-3

            var first = this.arr[0] || []//数据

            const company = this.arr[len]//单位
            const abscissa = this.arr[length] || []//x轴坐标
            const sign = this.arr[leng] || []//鼠标移入数据

            var _this = this
            const myChart = document.getElementById(id)
            this.ChartLineGraph = this.$echarts.init(myChart)
            this.ChartLineGraph.setOption({
            color: ['#3398DB'],
            tooltip: {
              trigger: 'axis',
              axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
              }
            },
            title: [
              {
                subtext: `单位: ${company}`,
                textStyle: {
                  color: 'rgba(255, 255, 255, 0.6)'
                }
              }
            ],
            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true
            },
            xAxis: [
              {
                type: 'category',
                data: abscissa,
                axisTick: {
                  alignWithLabel: true
                },
                axisLine: {
                  show: false,
                  lineStyle: {
                      type: 'solid',
                      color: this.axisColor,//坐标线的颜色
                  }
                },
                axisLabel: {
                  interval: 0, // 强制让每个坐标都显示
                  rotate: -0
                }
              }
            ],
            yAxis: [
              {
                type: 'value',
                axisLine: {
                  show: false,
                  lineStyle: {
                      type: 'solid',
                      color: this.axisColor,//坐标线的颜色
                  }
                },
                axisTick: {
                  show: false
                },
                splitLine: {
                  lineStyle: {
                    type: 'dashed'
                  },
                  show: true
                }
              }
            ],
            series: [
              {
                name: sign,
                type: 'bar',
                barWidth: '20px',
                itemStyle: {
                  normal: {
                    barBorderRadius: [10, 10, 0, 0],
                    color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(17, 216, 216, 1)'
                    }, {
                        offset: 1,
                        color: 'rgba(17, 216, 216, 0.5)'
                    }]),
                  }
                },
                data: first
              }
            ]
          },true)
            window.addEventListener('resize',function () {
              _this.ChartLineGraph.resize()
            })

           this.ChartLineGraph.on('dataZoom',(event)=>{
             if(event.batch){
               this.start=event.batch[0].start
               this.end=event.batch[0].end
             }else{
               this.start=event.start
               this.end=event.end
             }
           })

         }
        },
        beforeDestroy() {
          if(this.ChartLineGraph){
             this.ChartLineGraph.clear()
          }
      }
    }
</script>
 
<style lang="less" scoped>
</style>