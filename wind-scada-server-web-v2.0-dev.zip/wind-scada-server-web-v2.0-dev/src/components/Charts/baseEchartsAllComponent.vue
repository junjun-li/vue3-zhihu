<template>
  <div :id="id" :data="data"></div>
</template>

<script>
  // require('echarts/theme/macarons') // echarts theme
  export default {
        name: 'BaseEchartsAllComponent',
        data(){
          return{
            ChartLineGraph:null,
            arr:[],
            start: 0,
            end: 100
          }
        },
        watch:{
          data:{
            handler(newvalue,oldvalue) {
              this.drawLineGraph(this.id,newvalue)
            },
            deep:true
            }
          
        },
        props:{
            id: {
            type: String,
            default: ''
            },
            data: {
            type: Object,
            required: true
            }
        },
        mounted() {
          this.$nextTick(function(){
            setTimeout(() => {
              this.drawLineGraph(this.id,this.data)
            })
          })
        },
        methods:{
         drawLineGraph(id,data){
             this.arr = []
             for(var k in data){
                this.arr.push(data[k])
            }
            const length = this.arr.length-2
            const len = this.arr.length -1
            const legend = this.arr[length] || []
            var first = []
                  first = this.arr[0] || []
            const second = this.arr[1] || []
            const third = this.arr[2] || []
            const four = this.arr[3] || []
            const name = this.arr[len]
            const _this = this
            // document.getElementById(id).removeAttribute('_echarts_instance_')
            const myChart = document.getElementById(id)
            this.ChartLineGraph = this.$echarts.init(myChart)
            this.ChartLineGraph.setOption({
            tooltip: {
                trigger: 'axis'
            },
            grid: {
              top: 70,
              bottom: 50,
              left: 50,
              right: 50,
            },
            legend: {
              left:0,
              data: legend
            },

            calculable: true,
            xAxis: [{
                axisLabel: {
                interval: 0
                },
                axisLine: {
                lineStyle: {
                    color: '#CECECE'
                }
                },
                // min: (data.xyPoints[0][0]-0.01),
                type: 'time',
                boundaryGap: false,
                splitLine: {
                show: true,
                interval: 'auto',
                lineStyle: {
                    color: ['#FBFBFB']
                }
                },
                axisTick: {
                show: false
                },
            }],
            yAxis: [{
                name: name ? name[0] : [],
                type: 'value',
                name:name[0],
                splitLine: {
                lineStyle: {
                    color: ['#D4DFF5']
                }
                },
                axisLine: {
                lineStyle: {
                    color: '#CECECE'
                }
                }
            },{
              name: name ? name[1] : [],
              type: 'value',
              position: 'right',
              splitLine: {
                lineStyle: {
                  color: ['#D4DFF5']
                }
              },
              axisLine: {
                lineStyle: {
                  color: '#CECECE'
                }
              }
            }],
            dataZoom: [
              {
                type: 'slider',
                show: true,
                start: this.start,
                end: this.end,
                height: 18,
                bottom: 0
              },
              {
                type: 'inside',
                show: true,
                start: this.start,
                end: this.end,
            }],
            axisTick: {
                show: false
            },
            series: [{
                name: legend[0],
                type: 'line',
                yAxisIndex: 0,
                symbol: 'none',
                smooth: false,
                color: ['#5D7092'],
                data: first,
                lineStyle: {
                normal: {
                    width: 1
                }
                }
            },
                {
                name: legend[1],
                type: 'line',
                yAxisIndex: 0,
                symbol: 'none',
                symbolSize: 7,
                smooth: false,
                color: ['#5AD8A6'],
                data: second,
                lineStyle: {
                    normal: {
                    width: 1
                    }
                }
            },
                 {
                name: legend[2],
                type: 'line',
                yAxisIndex: 0,
                symbol: 'none',
                symbolSize: 7,
                smooth: false,
                color: ['#0068b7'],
                data: third,
                lineStyle: {
                    normal: {
                    width: 1
                    }
                }
            },
            {
                name: legend[3],
                type: 'line',
                yAxisIndex:1,
                symbol: 'none',
                symbolSize: 7,
                smooth: false,
                color: ['#F6BD16'],
                data: four,
                lineStyle: {
                    normal: {
                    width: 1
                    }
                }
            }
            ]

            },true)
            window.addEventListener('resize',function () {
              _this.ChartLineGraph.resize()
            })

           this.ChartLineGraph.on('dataZoom',(event)=>{
             if(event.batch){
               this.start=event.batch[0].start
               this.end=event.batch[0].end
             }else{
               this.start=event.start
               this.end=event.end
             }
           })

         }
        },
        beforeDestroy() {
          if(this.ChartLineGraph){
             this.ChartLineGraph.clear()
          }
      }
    }
</script>
 
<style lang="less" scoped>
</style>