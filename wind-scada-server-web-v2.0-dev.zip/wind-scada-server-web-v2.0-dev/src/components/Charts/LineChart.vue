<template>
  <!--全场有功功率图-->
  <div :class="className" :style="{height:height,width:width}">
  </div>
</template>

<script>
  // require('echarts/theme/macarons') // echarts theme

  export default {
    name: 'LineChart',
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '400px'
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null,
        start: 0,
        end: 100
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    created() {
      
    },
    mounted() {
      this.$nextTick(() => {
        setTimeout(() => {
        this.initChart()
        })
      })
    },
    beforeDestroy() {
      if (!this.chart) {
        return
      }
      this.chart.dispose()
      this.chart = null
    },
    methods: {
      initChart() {
        this.chart = this.$echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({ GridPower, GridRePower, IdealPower,Frequency, a, b, c, x, y, z } = {}) {//实际值 目标值 理论值 fact, target, theory
        this.chart.setOption({
          tooltip: {
                trigger: 'axis'
          },
          grid: {
            top: 70,
            bottom: 50,
            left: 50,
            right: 50,
          },
          legend: {
            left:30,
            data: this.chartData.legend
          },

          calculable: true,
          xAxis: {
            data: this.chartData.timeList ? this.chartData.timeList : [],
            axisLine: {
              lineStyle: {
                color: '#CECECE'
              }
            },
            boundaryGap: false,
            splitLine: {
              show: true,
              interval: 'auto',
              lineStyle: {
                color: ['#FBFBFB']
              }
            },
            axisTick: {
              show: false
            },
          },
          yAxis: {
            type: 'value',
            name: this.chartData.name,
            splitLine: {
              lineStyle: {
                color: ['#D4DFF5']
              }
            },
            axisLine: {
              lineStyle: {
                color: '#CECECE'
              }
            }
          },
          dataZoom: [
            {
              type: 'slider',
              show: true,
              start: this.start,
              end: this.end,
              height: 18,
              bottom: 0
            },
            {
              type: 'inside',
              show: true,
              start: this.start,
              end: this.end,
            }],
          axisTick: {
              show: false
          },
          series: [{
            name: this.chartData.legend[0],
            type: 'line',
            yAxisIndex: 0,
            symbol: 'none',
            smooth: false,
            color: ['#5D7092'],
            data: GridPower,
            lineStyle: {
            normal: {
                width: 1
            }
            }
          }, {
            name: this.chartData.legend[1],
            type: 'line',
            yAxisIndex: 0,
            symbol: 'none',
            smooth: false,
            color: ['#5AD8A6'],
            data: GridRePower,
            lineStyle: {
            normal: {
                width: 1
            }
            }
          },
            {
              name: this.chartData.legend[2],
              type: 'line',
              yAxisIndex: 0,
              symbol: 'none',
              smooth: false,
              color: ['#0068b7'],
              data: IdealPower,
              lineStyle: {
              normal: {
                  width: 1
              }
              }
            },        
          ]
        })
        this.chart.on('dataZoom',(event)=>{
          if(event.batch){
            this.start=event.batch[0].start
            this.end=event.batch[0].end
          }else{
            this.start=event.start
            this.end=event.end
          }
        })
      }
    }
  }
</script>
<style lang="less" scoped>

</style>